-- =============================================
-- Change DB for new fina
-- =============================================
alter table IN_RETURN_ITEMS add nvalue float;

create or replace  view result_view as
select ri.value, ri.nvalue, ri.nodeid, s.bankid, p.periodtypeid, p.fromdate, p.todate, p.id as periodid
     from in_schedules s, 
          in_periods p, 
          in_returns r,
          in_return_items ri
     where 
       s.periodid = p.id and r.scheduleid=s.id and ri.returnid=r.id;