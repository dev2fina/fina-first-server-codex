1. Introduction.

The database of FinA 3.3 is not fully compatible with older versions, i.e. FinA 3.3 server will not work with old databases for previous FinA versions. The purpose of this document is to give you step by step instructions to migrate your existing data and make your database compatible with FinA 3.3 server.

2. Migrating your database.

    1.	Backup your existing database.
    2.	Execute alter-db.sql script on existing database.
    3.	Edit convert.conf file and replace <HOST>, <PORT>, <SID>, <USER> and <PASSWORD> strings with appropriate values.
    4.	Run convert.bat

NOTE: Time needed to convert your database depends on your database size and server hardware, for 10'000'000 entries in your database this procedure will take approximately 2 hours.

When all above steps are performed successfully you should be able to run FinA 3.3 server without issues.

3. Additional information about compatibility.

Once migration is done you should always import data with FinA version 3.3, otherwise generated reports will not contain correct data. The information imported in FinA (return data), is stored differently in FinA version 3.3, thus this version will not process data imported with older versions.

It's acknowledged that in certain cases, or during transition period, on already converted database, new reports may be imported with FinA version older then 3.3. In this case prior to generating reports converter utility should be ran again. There is no need to execute SQL script, this task is performed only once. Note that running converter several times is safe and will not cause issues, the converter will perform task much faster then first time, i.e. it shouldn't take more than several minutes. Thus if you are not sure whether your database contains data imported by old FinA, you can always run converter.
