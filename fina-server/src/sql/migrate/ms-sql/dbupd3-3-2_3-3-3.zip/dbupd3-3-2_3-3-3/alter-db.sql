-- =============================================
-- Change DB for new fina
-- =============================================
IF NOT EXISTS(SELECT c.name 
	  FROM 	 sysobjects t, syscolumns c
	  WHERE  t.name = N'IN_RETURN_ITEMS' 
	  AND    c.name=N'NVALUE'
	  AND 	 t.type = 'U'
	  AND    c.id=t.id)
   alter table IN_RETURN_ITEMS add nvalue float
go

IF EXISTS(SELECT name 
	  FROM 	 sysobjects 
	  WHERE  name = N'RESULT_VIEW' 
	  AND 	 type = 'V')
    DROP VIEW RESULT_VIEW
go

create  view result_view as
select ri.value, ri.nvalue, ri.nodeid, s.bankid, p.periodtypeid, p.fromdate, p.todate, p.id as periodid
     from in_schedules s, 
          in_periods p, 
          in_returns r,
          in_return_items ri
     where 
       s.periodid = p.id and r.scheduleid=s.id and ri.returnid=r.id
go
